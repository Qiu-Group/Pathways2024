#!/bin/bash

module purge
module load mpi4py
module load SciPy-bundle/2023.02-gfbf-2022b
module load Jupyter-bundle
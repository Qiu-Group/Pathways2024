Parallel programming tutorial with MPI. 
